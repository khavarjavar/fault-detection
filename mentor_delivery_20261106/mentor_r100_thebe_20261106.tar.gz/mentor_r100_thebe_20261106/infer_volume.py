#!/usr/bin/env python3
"""Run the frozen R100 fault detector on one 3-D seismic volume."""

from __future__ import annotations

import argparse
from contextlib import nullcontext
import hashlib
import json
from pathlib import Path
import sys
import time

import h5py
import numpy as np
import torch

from models import build_r100


PATCH = 128
THRESHOLD = 0.1923828125
CHECKPOINT_NAME = "r100_epoch144.pth"
CHECKPOINT_SHA256 = "d2e5510f19c22121293d90fc1db9ab88f99aa22d51e64b37faae1975f3c6df80"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def verify_checkpoints(weights_dir: Path) -> None:
    path = weights_dir / CHECKPOINT_NAME
    if not path.is_file():
        raise FileNotFoundError(f"Missing checkpoint: {path}")
    actual = sha256(path)
    if actual != CHECKPOINT_SHA256:
        raise RuntimeError(f"Checkpoint hash mismatch for {path}: {actual}")


def load_state(model: torch.nn.Module, path: Path) -> None:
    checkpoint = torch.load(path, map_location="cpu", weights_only=True)
    state = checkpoint["model"] if isinstance(checkpoint, dict) and "model" in checkpoint else checkpoint
    model.load_state_dict(state, strict=True)


class VolumeSource:
    def __init__(self, path: Path, dataset: str, axes: str) -> None:
        if sorted(axes) != ["x", "y", "z"] or len(axes) != 3:
            raise ValueError("--axes must contain x, y, z exactly once, for example xyz or zyx")
        self.path = path
        self.dataset_name = dataset
        self.axes = axes
        self.handle = None
        suffix = path.suffix.lower()
        if suffix == ".npy":
            self.array = np.load(path, mmap_mode="r")
        elif suffix == ".npz":
            self.handle = np.load(path, mmap_mode="r")
            if dataset not in self.handle:
                raise KeyError(f"Dataset '{dataset}' not found; available: {list(self.handle.keys())}")
            self.array = self.handle[dataset]
        elif suffix in {".h5", ".hdf5"}:
            self.handle = h5py.File(path, "r")
            if dataset not in self.handle:
                raise KeyError(f"Dataset '{dataset}' not found in {path}")
            self.array = self.handle[dataset]
        elif suffix in {".sgy", ".segy"}:
            try:
                import segyio
            except ImportError as error:
                raise RuntimeError("SEG-Y input requires: python -m pip install segyio") from error
            self.handle = segyio.open(str(path), "r", ignore_geometry=False)
            self.array = segyio.tools.cube(self.handle)
            if axes != "xyz":
                raise ValueError("SEG-Y cube order is inline,crossline,sample; use --axes xyz")
        else:
            raise ValueError("Input must be .npy, .npz, .h5, .hdf5, .sgy, or .segy")
        if self.array.ndim != 3:
            raise ValueError(f"Expected a 3-D volume, found shape {self.array.shape}")
        if not np.issubdtype(self.array.dtype, np.number):
            raise TypeError(f"Expected numeric input, found {self.array.dtype}")
        self.shape = tuple(int(value) for value in self.array.shape)
        self.shape_xyz = tuple(self.shape[axes.index(axis)] for axis in "xyz")

    def read_xyz(self, starts: tuple[int, int, int], stops: tuple[int, int, int]) -> np.ndarray:
        slices_xyz = {axis: slice(start, stop) for axis, start, stop in zip("xyz", starts, stops)}
        source_slices = tuple(slices_xyz[axis] for axis in self.axes)
        block = np.asarray(self.array[source_slices], dtype=np.float32)
        to_xyz = tuple(self.axes.index(axis) for axis in "xyz")
        return np.transpose(block, to_xyz)

    def output_slices(self, starts: tuple[int, int, int], stops: tuple[int, int, int]):
        slices_xyz = {axis: slice(start, stop) for axis, start, stop in zip("xyz", starts, stops)}
        return tuple(slices_xyz[axis] for axis in self.axes)

    def from_xyz(self, block: np.ndarray) -> np.ndarray:
        return np.transpose(block, tuple("xyz".index(axis) for axis in self.axes))

    def close(self) -> None:
        if self.handle is not None:
            self.handle.close()


def autocast_context(device: torch.device):
    if device.type == "cuda":
        return torch.autocast("cuda", dtype=torch.float16)
    return nullcontext()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, required=True, help="3-D seismic volume")
    parser.add_argument("--output", type=Path, required=True, help="New .h5 result file")
    parser.add_argument("--dataset", default="seismic", help="Input key for HDF5/NPZ")
    parser.add_argument(
        "--axes", default="xyz",
        help="Input array axis order. x=inline, y=crossline, z=time/depth; default xyz",
    )
    parser.add_argument(
        "--valid-all", action="store_true",
        help="Treat finite zero amplitudes as data. Default matches training: zero means no-data.",
    )
    parser.add_argument("--device", choices=("cuda", "cpu"), default="cuda")
    parser.add_argument("--overwrite", action="store_true")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    root = Path(__file__).resolve().parent
    weights_dir = root / "weights"
    verify_checkpoints(weights_dir)
    if args.output.suffix.lower() not in {".h5", ".hdf5"}:
        raise ValueError("--output must end in .h5 or .hdf5")
    if args.output.exists() and not args.overwrite:
        raise FileExistsError(f"Output exists: {args.output}; use --overwrite to replace it")
    if args.device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but no CUDA GPU is available; use --device cpu only for small tests")
    device = torch.device(args.device)

    print("Loading checkpoints...", flush=True)
    model = build_r100()
    load_state(model, weights_dir / CHECKPOINT_NAME)
    model.to(device).eval()

    source = VolumeSource(args.input, args.dataset, args.axes)
    total = int(np.prod([int(np.ceil(length / PATCH)) for length in source.shape_xyz]))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    started = time.time()
    try:
        with h5py.File(args.output, "w") as output:
            chunks = tuple(min(PATCH, length) for length in source.shape)
            probability_out = output.create_dataset(
                "fault_probability", shape=source.shape, dtype=np.float16,
                chunks=chunks, compression="gzip", compression_opts=4,
            )
            mask_out = output.create_dataset(
                "fault_mask", shape=source.shape, dtype=np.uint8,
                chunks=chunks, compression="gzip", compression_opts=4,
            )
            output.attrs["input"] = str(args.input)
            output.attrs["input_dataset"] = args.dataset
            output.attrs["axes"] = args.axes
            output.attrs["patch_size"] = PATCH
            output.attrs["model"] = "FaultSeg3D R100 epoch 144"
            output.attrs["threshold"] = THRESHOLD
            output.attrs["validity"] = "all finite" if args.valid_all else "finite and nonzero"

            number = 0
            with torch.inference_mode():
                for x0 in range(0, source.shape_xyz[0], PATCH):
                    for y0 in range(0, source.shape_xyz[1], PATCH):
                        for z0 in range(0, source.shape_xyz[2], PATCH):
                            starts = (x0, y0, z0)
                            stops = tuple(
                                min(start + PATCH, length)
                                for start, length in zip(starts, source.shape_xyz)
                            )
                            raw = source.read_xyz(starts, stops)
                            valid = np.isfinite(raw)
                            if not args.valid_all:
                                valid &= raw != 0.0
                            normalized = np.zeros(raw.shape, dtype=np.float32)
                            if valid.any():
                                values = raw[valid].astype(np.float64, copy=False)
                                mean = float(values.mean())
                                std = float(values.std())
                                if std > 0.0 and np.isfinite(std):
                                    normalized[valid] = (raw[valid] - mean) / std
                            padded = np.zeros((PATCH, PATCH, PATCH), dtype=np.float32)
                            extents = tuple(stop - start for start, stop in zip(starts, stops))
                            bounds_xyz = tuple(slice(0, extent) for extent in extents)
                            padded[bounds_xyz] = normalized
                            model_input = torch.from_numpy(
                                np.ascontiguousarray(padded.transpose(2, 1, 0))[None, None]
                            ).to(device)
                            with autocast_context(device):
                                logits = model(model_input)
                            probability_zyx = torch.sigmoid(logits.float())[0, 0].cpu().numpy()
                            probability_xyz = probability_zyx.transpose(2, 1, 0)[bounds_xyz]
                            probability_xyz[~valid] = 0.0
                            fault_xyz = probability_xyz >= THRESHOLD
                            output_slices = source.output_slices(starts, stops)
                            probability_out[output_slices] = source.from_xyz(probability_xyz)
                            mask_out[output_slices] = source.from_xyz(fault_xyz.astype(np.uint8))
                            number += 1
                            if number == 1 or number % 10 == 0 or number == total:
                                print(f"patch {number}/{total}", flush=True)
            output.attrs["elapsed_seconds"] = time.time() - started
            output.attrs["model_manifest"] = json.dumps({
                "checkpoint": CHECKPOINT_NAME,
                "checkpoint_sha256": CHECKPOINT_SHA256,
                "selected_epoch": 144,
            })
    finally:
        source.close()
    print(f"Wrote {args.output} in {time.time() - started:.1f} seconds", flush=True)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as error:
        print(f"ERROR: {error}", file=sys.stderr)
        raise

