#!/usr/bin/env python3
"""Verify the R100 checkpoint and run a small inference test."""

from pathlib import Path

import numpy as np
import torch

from infer_volume import CHECKPOINT_SHA256, load_state, sha256
from models import build_r100


def main() -> int:
    root = Path(__file__).resolve().parent
    checkpoint = root / "weights" / "r100_epoch144.pth"
    actual = sha256(checkpoint)
    if actual != CHECKPOINT_SHA256:
        raise RuntimeError(f"Checkpoint hash mismatch: {actual}")

    model = build_r100()
    load_state(model, checkpoint)
    model.eval()
    rng = np.random.default_rng(43)
    sample = torch.from_numpy(rng.normal(size=(1, 1, 16, 16, 16)).astype(np.float32))
    with torch.inference_mode():
        probability = torch.sigmoid(model(sample))
    if probability.shape != sample.shape or not torch.isfinite(probability).all():
        raise RuntimeError("Invalid CPU inference output")
    print("PASS: checkpoint hash and model definition are correct")
    print(f"PASS: CPU inference output {tuple(probability.shape)} is finite")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
